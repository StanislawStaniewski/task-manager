﻿using System.Text.Json.Serialization;

namespace SCRUM.Models;

public enum WorkStatus { Backlog, Todo, InProgress, Done }
public enum Priority { Low, Medium, High }
public enum SprintState { Planned, Active, Closed }
public enum BugSeverity { Minor, Major, Critical }

public class Workspace
{
    public int Id { get; set; }
    public string Name { get; set; } = "My Workspace";
    public List<Project> Projects { get; set; } = new();
}

public class Project
{
    public int Id { get; set; }
    public string Name { get; set; } = "My Project";
    public string KeyPrefix { get; set; } = "PROJ";

    public int NextIssueNumber { get; set; } = 1;

    public List<IssueBase> Issues { get; set; } = new();
    public List<Sprint> Sprints { get; set; } = new();
    public List<ActivityEvent> Activity { get; set; } = new();

    public string NextKey()
    {
        var key = $"{KeyPrefix}-{NextIssueNumber}";
        NextIssueNumber++;
        return key;
    }
}

public class Sprint
{
    public int Id { get; set; }
    public string Name { get; set; } = "Sprint 1";
    public DateTime StartDate { get; set; } = DateTime.Today;
    public DateTime EndDate { get; set; } = DateTime.Today.AddDays(14);
    public SprintState State { get; set; } = SprintState.Planned;

    public List<int> IssueIds { get; set; } = new();
}

// F
[JsonPolymorphic(TypeDiscriminatorPropertyName = "$type")]
[JsonDerivedType(typeof(UserStory), "story")]
[JsonDerivedType(typeof(Bug), "bug")]
[JsonDerivedType(typeof(TaskItem), "task")]
public abstract class IssueBase
{
    public int Id { get; set; }
    public string Key { get; set; } = "";
    public string Title { get; private set; } = "";
    public string? Description { get; private set; }

    public WorkStatus Status { get; private set; } = WorkStatus.Backlog;
    public Priority Priority { get; private set; } = Priority.Medium;

    public string? Assignee { get; private set; }

    public int? SprintId { get; private set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime UpdatedAt { get; private set; } = DateTime.Now;

    protected IssueBase() { }

    protected IssueBase(string title, Priority priority)
    {
        Title = title;
        Priority = priority;
        Touch();
    }

    public void SetDescription(string? text)
    {
        Description = text;
        Touch();
    }

    public void AssignTo(string? user)
    {
        Assignee = string.IsNullOrWhiteSpace(user) ? null : user.Trim();
        Touch();
    }

    public void MoveTo(WorkStatus newStatus)
    {
        Status = newStatus;
        Touch();
    }

    public void AddToSprint(int sprintId)
    {
        SprintId = sprintId;
        Touch();
    }

    public void RemoveFromSprint()
    {
        SprintId = null;
        Touch();
    }

    protected void Touch() => UpdatedAt = DateTime.Now;

    // Poli
    public abstract string TypeLabel();
}

public class UserStory : IssueBase
{
    public int StoryPoints { get; private set; } = 1;

    public UserStory() { }

    public UserStory(string title, Priority priority, int storyPoints)
        : base(title, priority)
    {
        StoryPoints = Math.Max(1, storyPoints);
    }

    public override string TypeLabel() => "Story";
}

public class Bug : IssueBase
{
    public BugSeverity Severity { get; private set; } = BugSeverity.Major;

    public Bug() { }

    public Bug(string title, Priority priority, BugSeverity severity)
        : base(title, priority)
    {
        Severity = severity;
    }

    public override string TypeLabel() => "Bug";
}

public class TaskItem : IssueBase
{
    public double EstimatedHours { get; private set; } = 1;

    public TaskItem() { }

    public TaskItem(string title, Priority priority, double hours)
        : base(title, priority)
    {
        EstimatedHours = Math.Max(0.5, hours);
    }

    public override string TypeLabel() => "Task";
}

public class ActivityEvent
{
    public DateTime At { get; set; } = DateTime.Now;
    public string Message { get; set; } = "";
}
