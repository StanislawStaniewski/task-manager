﻿using System.Text.Json;
using SCRUM.Models;

namespace SCRUM.Services;

public class ScrumStore
{
    private readonly string _filePath;

    public Workspace Workspace { get; private set; } = new Workspace
    {
        Id = 1,
        Name = "Workspace",
        Projects = new List<Project>
        {
            new Project { Id = 1, Name = "Mini-Huly", KeyPrefix = "HULY" }
        }
    };

    private readonly JsonSerializerOptions _jsonOptions = new()
    {
        WriteIndented = true
    };

    public ScrumStore(IWebHostEnvironment env)
    {
        _filePath = Path.Combine(env.ContentRootPath, "App_Data", "scrum-data.json");
        Load();
        EnsureSeed();
        Save();
    }

    private void EnsureSeed()
    {
        if (!Workspace.Projects.Any())
            Workspace.Projects.Add(new Project { Id = 1, Name = "Mini-Huly", KeyPrefix = "HULY" });
    }

    public Project GetProject(int projectId)
    {
        return Workspace.Projects.First(p => p.Id == projectId);
    }

    public void Save()
    {
        var dir = Path.GetDirectoryName(_filePath);
        if (!Directory.Exists(dir))
            Directory.CreateDirectory(dir!);

        var json = JsonSerializer.Serialize(Workspace, _jsonOptions);
        File.WriteAllText(_filePath, json);
    }

    public void Load()
    {
        if (!File.Exists(_filePath))
            return;

        var json = File.ReadAllText(_filePath);
        var data = JsonSerializer.Deserialize<Workspace>(json, _jsonOptions);
        if (data != null)
            Workspace = data;
    }

    // --------- Operacje "systemowe" ---------

    public IssueBase AddIssue(int projectId, string kind, string title, Priority priority, string? assignee, int storyPoints, BugSeverity severity, double hours)
    {
        var p = GetProject(projectId);

        IssueBase issue;
        if (kind == "story")
            issue = new UserStory(title, priority, storyPoints);
        else if (kind == "bug")
            issue = new Bug(title, priority, severity);
        else
            issue = new TaskItem(title, priority, hours);

        issue.Id = NextId(p);
        issue.Key = p.NextKey();
        issue.AssignTo(assignee);

        p.Issues.Add(issue);
        p.Activity.Insert(0, new ActivityEvent { Message = $"Dodano {issue.TypeLabel()} {issue.Key}: {issue.Title}" });

        Save();
        return issue;
    }

    public bool MoveIssue(int projectId, int issueId, WorkStatus newStatus, int wipLimit = 3)
    {
        var p = GetProject(projectId);
        var issue = p.Issues.First(i => i.Id == issueId);

        // WIP limit jako "pro" warunek
        if (newStatus == WorkStatus.InProgress)
        {
            var inProg = p.Issues.Count(i => i.Status == WorkStatus.InProgress);
            if (inProg >= wipLimit)
                return false;
        }

        var old = issue.Status;
        issue.MoveTo(newStatus);

        p.Activity.Insert(0, new ActivityEvent { Message = $"Zmieniono status {issue.Key}: {old} → {newStatus}" });
        Save();
        return true;
    }

    public void Assign(int projectId, int issueId, string? user)
    {
        var p = GetProject(projectId);
        var issue = p.Issues.First(i => i.Id == issueId);

        issue.AssignTo(user);
        p.Activity.Insert(0, new ActivityEvent { Message = $"Przypisano {issue.Key} do: {(issue.Assignee ?? "brak")}" });
        Save();
    }

    public Sprint AddSprint(int projectId, string name, DateTime start, DateTime end)
    {
        var p = GetProject(projectId);
        var sprint = new Sprint
        {
            Id = p.Sprints.Any() ? p.Sprints.Max(s => s.Id) + 1 : 1,
            Name = string.IsNullOrWhiteSpace(name) ? $"Sprint {p.Sprints.Count + 1}" : name.Trim(),
            StartDate = start,
            EndDate = end,
            State = SprintState.Planned
        };

        p.Sprints.Add(sprint);
        p.Activity.Insert(0, new ActivityEvent { Message = $"Dodano sprint: {sprint.Name}" });
        Save();

        return sprint;
    }

    public void StartSprint(int projectId, int sprintId)
    {
        var p = GetProject(projectId);

        foreach (var s in p.Sprints)
        {
            if (s.Id == sprintId) s.State = SprintState.Active;
            else if (s.State == SprintState.Active) s.State = SprintState.Closed;
        }

        p.Activity.Insert(0, new ActivityEvent { Message = $"Uruchomiono sprint ID={sprintId}" });
        Save();
    }

    public void CloseSprint(int projectId, int sprintId)
    {
        var p = GetProject(projectId);
        var s = p.Sprints.First(x => x.Id == sprintId);
        s.State = SprintState.Closed;

        p.Activity.Insert(0, new ActivityEvent { Message = $"Zamknięto sprint: {s.Name}" });
        Save();
    }

    public void AddIssueToSprint(int projectId, int issueId, int sprintId)
    {
        var p = GetProject(projectId);
        var issue = p.Issues.First(i => i.Id == issueId);
        var sprint = p.Sprints.First(s => s.Id == sprintId);

        issue.AddToSprint(sprintId);
        if (!sprint.IssueIds.Contains(issueId))
            sprint.IssueIds.Add(issueId);

        p.Activity.Insert(0, new ActivityEvent { Message = $"Dodano {issue.Key} do sprintu: {sprint.Name}" });
        Save();
    }

    public void RemoveIssueFromSprint(int projectId, int issueId)
    {
        var p = GetProject(projectId);
        var issue = p.Issues.First(i => i.Id == issueId);

        if (issue.SprintId.HasValue)
        {
            var sprint = p.Sprints.FirstOrDefault(s => s.Id == issue.SprintId.Value);
            sprint?.IssueIds.Remove(issueId);
        }

        issue.RemoveFromSprint();
        p.Activity.Insert(0, new ActivityEvent { Message = $"Usunięto issue ze sprintu: {issue.Key}" });
        Save();
    }

    private int NextId(Project p) => p.Issues.Any() ? p.Issues.Max(i => i.Id) + 1 : 1;

    // To jest celowo proste (studenckie) — jedna metoda ID.
}
